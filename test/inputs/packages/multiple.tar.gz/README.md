Repository with multiple packages.
